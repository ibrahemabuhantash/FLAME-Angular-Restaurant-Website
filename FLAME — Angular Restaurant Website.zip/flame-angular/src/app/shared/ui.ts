import { Component, input, output, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Product,money } from '../core/catalog';
import { CartService } from '../core/cart.service';
@Component({selector:'fl-intro',imports:[],template:`<section class="intro dark"><div class="wrap stack"><p class="eyebrow">{{eyebrow()}}</p><h1>{{title()}}</h1><p class="lead">{{description()}}</p></div></section>`})
export class IntroComponent {eyebrow=input.required<string>();title=input.required<string>();description=input.required<string>();}
@Component({selector:'fl-card',imports:[RouterLink],template:`<article class="food-card"><a class="food-art" [class]="product().color" [routerLink]="['/menu',product().id]" [attr.aria-label]="'Details for '+product().name"><img [src]="'assets/'+product().art" [alt]="product().name+' illustration'" width="400" height="211"></a><div class="card-body"><h3><a [routerLink]="['/menu',product().id]">{{product().name}}</a></h3><p class="muted">{{product().description}}</p><div class="between"><strong>{{money(product().price)}}</strong><button class="btn" (click)="add()" [attr.aria-label]="'Add '+product().name+' to bag'">Add +</button></div><span class="sr-only" role="status">{{notice()}}</span></div></article>`})
export class CardComponent{product=input.required<Product>();cart=inject(CartService);money=money;notice=signal('');add(){this.cart.add(this.product());this.notice.set(this.product().name+' added. '+this.cart.count()+' items in bag.');}}
@Component({selector:'fl-quantity',template:`<div class="quantity"><button type="button" aria-label="Decrease quantity" [disabled]="value()<=min()" (click)="changed.emit(value()-1)">−</button><span aria-live="polite">{{value()}}</span><button type="button" aria-label="Increase quantity" [disabled]="value()>=99" (click)="changed.emit(value()+1)">+</button></div>`})
export class QuantityComponent{value=input.required<number>();min=input(1);changed=output<number>();}
