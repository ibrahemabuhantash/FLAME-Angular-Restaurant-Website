export type Category = 'Burgers' | 'Chicken' | 'Sides';
export type Recipe = 'standard' | 'no-sauce';
export type Product = { id:string; name:string; description:string; category:Category; price:number; art:string; color:string };
// Prices use integer fils (1 JOD = 1000 fils), never floating point arithmetic.
export const PRODUCTS: readonly Product[] = [
 {id:'og-flame',name:'The OG Flame',description:'Smashed beef, cheddar, house sauce.',category:'Burgers',price:5500,art:'burger.svg',color:'orange'},
 {id:'crispy-heat',name:'Crispy Heat',description:'Crispy chicken, slaw, spicy mayo.',category:'Chicken',price:4750,art:'chicken.svg',color:'gold'},
 {id:'flame-fries',name:'Flame Fries',description:'Golden fries, signature seasoning.',category:'Sides',price:2250,art:'fries.svg',color:'sand'}
];
export const money = (fils:number) => (fils/1000).toFixed(2)+' JD';
