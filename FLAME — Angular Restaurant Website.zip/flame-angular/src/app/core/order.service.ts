import { Injectable, signal } from '@angular/core';
export type Receipt={id:string;method:'pickup'|'delivery';count:number;total:number};
@Injectable({providedIn:'root'})
export class OrderService{
 readonly receipt=signal<Receipt|null>(null);
 create(method:'pickup'|'delivery',count:number,total:number){const receipt:Receipt={id:'FL-'+Date.now().toString(36).toUpperCase(),method,count,total};this.receipt.set(receipt);return receipt;}
}
