import { Injectable, computed, signal } from '@angular/core';
import { PRODUCTS, Product, Recipe } from './catalog';
import { addLine, readCart, setQuantity, subtotal, lineKey } from './cart-logic';
const KEY='flame-cart-v1';
@Injectable({providedIn:'root'})
export class CartService {
 private initial(){try{return readCart(localStorage.getItem(KEY),PRODUCTS);}catch{return [];}}
 private readonly state=signal(this.initial());
 readonly lines=this.state.asReadonly();
 readonly count=computed(()=>this.lines().reduce((sum,l)=>sum+l.quantity,0));
 readonly subtotal=computed(()=>subtotal(this.lines(),PRODUCTS));
 readonly items=computed(()=>this.lines().map(l=>({...l,key:lineKey(l),product:PRODUCTS.find(p=>p.id===l.productId)!})));
 private save(){try{localStorage.setItem(KEY,JSON.stringify(this.lines()));}catch{/* still works in memory */}}
 add(product:Product,quantity=1,recipe:Recipe='standard'){this.state.update(lines=>addLine(lines,{productId:product.id,quantity,recipe}));this.save();}
 quantity(key:string,n:number){this.state.update(lines=>setQuantity(lines,key,n));this.save();}
 clear(){this.state.set([]);this.save();}
}
