export type Line = {productId:string;recipe:'standard'|'no-sauce';quantity:number};
export type PriceItem = {id:string;price:number};
export const MAX_QTY=99;
export const lineKey = (line:Line) => line.productId+':'+line.recipe;
export function readCart(raw:string|null, catalog:readonly PriceItem[]):Line[]{
 try{const value:unknown=JSON.parse(raw??'[]');if(!Array.isArray(value))return [];let result:Line[]=[];for(const x of value){if(x&&catalog.some(p=>p.id===x.productId)&&(x.recipe==='standard'||x.recipe==='no-sauce')&&Number.isInteger(x.quantity)&&x.quantity>0){result=addLine(result,{productId:x.productId,recipe:x.recipe,quantity:Math.min(MAX_QTY,x.quantity)});}}return result;}catch{return [];}
}
export function addLine(lines:readonly Line[], line:Line):Line[]{
 if(!Number.isInteger(line.quantity)||line.quantity<1)return [...lines];const key=lineKey(line);const existing=lines.find(x=>lineKey(x)===key);
 return existing?lines.map(x=>lineKey(x)===key?{...x,quantity:Math.min(MAX_QTY,x.quantity+line.quantity)}:x):[...lines,{...line,quantity:Math.min(MAX_QTY,line.quantity)}];
}
export function setQuantity(lines:readonly Line[], key:string, n:number):Line[]{if(!Number.isInteger(n))return [...lines];return lines.flatMap(x=>lineKey(x)!==key?[x]:n<=0?[]:[{...x,quantity:Math.min(MAX_QTY,n)}]);}
export function subtotal(lines:readonly Line[],catalog:readonly PriceItem[]):number{return lines.reduce((s,l)=>s+(catalog.find(p=>p.id===l.productId)?.price??0)*l.quantity,0);}
export const deliveryFee=(method:'pickup'|'delivery')=>method==='delivery'?1500:0;
